import { Parser } from 'expr-eval';
import { format, subDays, startOfDay, endOfDay } from 'date-fns';
import { type PrismaClient } from '../../../generated/prisma/index.js';

const parser = new Parser();

interface FormulaVariable {
  label: string;
  type: 'reading' | 'spec' | 'constant';
  readingTypeId?: number;
  timeShift?: number;
  specField?: string;
  meterId?: number;
}

interface FormulaItems {
  formula: string;
  variables: FormulaVariable[];
}

type TxClient = Omit<
  PrismaClient,
  '$connect' | '$disconnect' | '$on' | '$transaction' | '$use' | '$extends'
>;

const toPrismaDate = (d: Date | string): Date => {
  const dateObj = new Date(d);
  return new Date(Date.UTC(dateObj.getFullYear(), dateObj.getMonth(), dateObj.getDate()));
};

export const formulaEngine = {
  async run(meterId: number, readingDate: Date, tx: TxClient) {
    const meter = await tx.meter.findUnique({
      where: { meter_id: meterId },
      include: {
        calculation_template: { include: { definitions: true } },
      },
    });

    if (meter?.calculation_template) {
      await this.calculateSummary(meter, readingDate, tx);
    }

    const allPotentialMeters = await tx.meter.findMany({
      where: { calculation_template_id: { not: null } },
      include: { calculation_template: { include: { definitions: true } } },
    });

    const dependentMeters = allPotentialMeters.filter((vMeter) => {
      if (vMeter.meter_id === meterId) return false;
      const defs = vMeter.calculation_template?.definitions ?? [];
      return defs.some((df) => {
        const formulaData = df.formula_items as unknown as FormulaItems;
        const vars = formulaData?.variables ?? [];
        return vars.some((v) => v.meterId === meterId);
      });
    });

    for (const depMeter of dependentMeters) {
      await this.calculateSummary(depMeter, readingDate, tx);
    }
  },

  async calculateSummary(meter: any, date: Date, tx: TxClient) {
    console.log(`[FormulaEngine] Processing Meter: ${meter.meter_code}`);

    const dbDictionary = await this.buildDbDictionary(meter, date, tx);

    const summaryDetails = [];
    let totalUsage = 0;
    const usedFormulaTemplateId = meter.calculation_template_id;
    const definitions = meter.calculation_template?.definitions ?? [];

    for (const formulaDef of definitions) {
      try {
        const formulaData = formulaDef.formula_items as unknown as FormulaItems;
        const rawFormula = formulaData.formula;
        const variables = formulaData.variables ?? [];

        const scope: Record<string, number> = {};

        variables.forEach((v) => {
          const mId = v.meterId ?? meter.meter_id;

          if (v.type === 'spec') {
            const specField = (v.specField ?? 'multiplier').toUpperCase();
            const dictKey = `M${mId}_SPEC_${specField}`;
            scope[v.label] = dbDictionary[dictKey] ?? (specField === 'MULTIPLIER' ? 1 : 0);
          } else {
            const suffix = v.timeShift === -1 ? 'Prev' : 'H';
            const rtId = v.readingTypeId;
            const dictKey = `M${mId}_RT${rtId}_${suffix}`;
            scope[v.label] = dbDictionary[dictKey] ?? 0;
          }
        });

        const result = parser.evaluate(rawFormula, scope);

        summaryDetails.push({
          label: formulaDef.name,
          value: result,
        });

        if (formulaDef.is_main) {
          totalUsage += Number(result);
        }
      } catch (e) {
        console.error(
          `[FormulaEngine] Gagal hitung ${formulaDef.name} pada meter ${meter.meter_code}:`,
          e,
        );
      }
    }

    const prismaSafeDate = toPrismaDate(date);

    console.log(`[FormulaEngine] Safe Date dikirim ke DB: ${prismaSafeDate.toISOString()}`);

    await tx.dailySummary.upsert({
      where: {
        meter_id_summary_date: {
          meter_id: meter.meter_id,
          summary_date: prismaSafeDate,
        },
      },
      update: {
        total_usage: totalUsage,
        summary_details: { deleteMany: {}, create: summaryDetails },
        calculated_at: new Date(),
      },
      create: {
        meter_id: meter.meter_id,
        summary_date: prismaSafeDate,
        total_usage: totalUsage,
        total_cost: 0,

        used_formula_template_id: usedFormulaTemplateId ? String(usedFormulaTemplateId) : '',
        summary_details: { create: summaryDetails },
      },
    });
  },

  async buildDbDictionary(meter: any, targetDate: Date, tx: TxClient) {
    const dictionary: Record<string, number> = {};
    const datePrev = startOfDay(subDays(targetDate, 1));

    const requiredMeterIds = new Set<number>();
    requiredMeterIds.add(meter.meter_id);

    const definitions = meter.calculation_template?.definitions ?? [];
    definitions.forEach((df: any) => {
      const vars = (df.formula_items as unknown as FormulaItems)?.variables ?? [];
      vars.forEach((v) => {
        if (v.meterId) requiredMeterIds.add(v.meterId);
      });
    });

    const meterIdsArray = Array.from(requiredMeterIds);

    const metersSpecs = await tx.meter.findMany({
      where: { meter_id: { in: meterIdsArray } },
    });

    metersSpecs.forEach((m: any) => {
      dictionary[`M${m.meter_id}_SPEC_MULTIPLIER`] = Number(m.multiplier ?? 1);
      dictionary[`M${m.meter_id}_SPEC_INITIAL_READING`] = Number(m.initial_reading ?? 0);
    });

    const sessions = await tx.readingSession.findMany({
      where: {
        meter_id: { in: meterIdsArray },
        reading_date: {
          gte: datePrev,
          lte: endOfDay(targetDate),
        },
      },
      include: { details: true },
    });

    sessions.forEach((session: any) => {
      const isToday =
        format(session.reading_date, 'yyyy-MM-dd') === format(targetDate, 'yyyy-MM-dd');
      const suffix = isToday ? 'H' : 'Prev';

      session.details.forEach((det: any) => {
        const dictKey = `M${session.meter_id}_RT${det.reading_type_id}_${suffix}`;
        dictionary[dictKey] = Number(det.value);
      });
    });

    return dictionary;
  },
};
