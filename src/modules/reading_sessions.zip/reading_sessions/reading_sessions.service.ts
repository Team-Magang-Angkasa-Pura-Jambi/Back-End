import prisma from '../../configs/db.js';
import { handlePrismaError } from '../../common/utils/prismaError.js';
import { Error400, Error404 } from '../../utils/customError.js';
import {
  _checkUsageAgainstTargetAndNotify,
  _normalizeDate,
  _validateMeter,
} from './utils/reading.utils.js';
import { readingValidator } from './utils/reading.validator.js';
import { formulaEngine } from './utils/formula.engine.js';

interface PayloadRecalculate {
  start_date: string;
  to_date: string;
  meter_id: number;
}
export const readingService = {
  show: async (query: any) => {
    try {
      const { meter_id, from_date, to_date, page, limit } = query;
      const skip = (page - 1) * limit;

      const where: any = {};
      if (meter_id) where.meter_id = meter_id;
      if (from_date || to_date) {
        where.reading_date = {
          gte: from_date ? new Date(from_date) : undefined,
          lte: to_date ? new Date(to_date) : undefined,
        };
      }

      const [data, total] = await Promise.all([
        prisma.readingSession.findMany({
          where,
          skip,
          take: limit,
          orderBy: { reading_date: 'desc' },
          include: {
            details: { include: { reading_type: true } },

            captured_by: { select: { username: true } },
            meter: { select: { name: true } },
          },
        }),
        prisma.readingSession.count({ where }),
      ]);

      return { data, meta: { total, page, limit, total_pages: Math.ceil(total / limit) } };
    } catch (error) {
      return handlePrismaError(error, 'Reading Session');
    }
  },
  store: async (payload: any, userId: number) => {
    try {
      const { meter_id, reading_date, details, evidence_image_url, notes } = payload.reading;

      const dateForDb = _normalizeDate(reading_date);

      return await prisma.$transaction(async (tx: any) => {
        const meter = await _validateMeter(meter_id, tx);

        await readingValidator.validate(meter, dateForDb, details, tx);

        const session = await tx.readingSession.create({
          data: {
            meter_id,
            reading_date: dateForDb,
            captured_by_user_id: userId,
            evidence_image_url,
            notes,
            details: {
              create: details.map((d) => ({
                reading_type_id: d.reading_type_id,
                value: d.value,
              })),
            },
          },
          include: {
            details: {
              include: { reading_type: true },
            },
          },
        });

        await formulaEngine.run(meter_id, dateForDb, tx);
        console.log(`[readingService] Processing Meter: ${dateForDb}`);

        const summary = await tx.dailySummary.findUnique({
          where: {
            meter_id_summary_date: { meter_id, summary_date: dateForDb },
          },
        });
        if (summary) {
          await _checkUsageAgainstTargetAndNotify(userId, summary, meter, tx);
        }

        return session;
      });
    } catch (error) {
      return handlePrismaError(error, 'Reading Session');
    }
  },

  update: async (sessionId: number, payload: any, userId: number) => {
    try {
      // 1. Ekstrak payload (Mendukung jika dibungkus 'reading' atau dikirim langsung)
      const dataToUpdate = payload.reading || payload;
      const { meter_id, reading_date, details, evidence_image_url, notes } = dataToUpdate;

      // 2. Normalisasi Data (Sama seperti store)
      const dateForDb = _normalizeDate(reading_date);

      return await prisma.$transaction(async (tx: any) => {
        // 3. Ambil data lama untuk Audit Log dan ID
        const existingSession = await tx.readingSession.findUnique({
          where: { session_id: sessionId },
          include: { details: true },
        });

        if (!existingSession) {
          throw new Error('Reading session not found');
        }

        // 4. Validasi Meter & Nilai Pembacaan (Sama seperti store)
        const targetMeterId = meter_id || existingSession.meter_id;
        const meter = await _validateMeter(targetMeterId, tx);

        await readingValidator.validate(meter, dateForDb, details, tx);

        // 5. Eksekusi Update & Replace Details (Sama seperti store)
        const session = await tx.readingSession.update({
          where: { session_id: sessionId },
          data: {
            reading_date: dateForDb,
            evidence_image_url:
              evidence_image_url !== undefined
                ? evidence_image_url
                : existingSession.evidence_image_url,
            notes: notes !== undefined ? notes : existingSession.notes,
            details: {
              // Hapus data lama, ganti dengan array data baru
              deleteMany: {},
              create: details.map((d: any) => ({
                reading_type_id: d.reading_type_id,
                value: d.value,
              })),
            },
          },
          include: {
            details: {
              include: { reading_type: true },
            },
          },
        });

        // 6. Audit Log (Tambahan wajib untuk update)
        // PERBAIKAN 500 ERROR: Gunakan JSON.parse(JSON.stringify()) agar Date object aman masuk ke field db Json
        await tx.auditLog.create({
          data: {
            user_id: userId,
            action: 'UPDATE',
            entity_table: 'reading_sessions',
            entity_id: String(sessionId),
            old_values: JSON.parse(JSON.stringify(existingSession)),
            new_values: JSON.parse(JSON.stringify(session)),
            reason: 'User memperbarui nilai stand meteran',
          },
        });

        // 7. Hitung Ulang Formula (Sama seperti store)
        await formulaEngine.run(targetMeterId, dateForDb, tx);
        console.log(`[readingService] Re-Processing Meter: ${dateForDb}`);

        // 8. Cek Daily Summary & Notifikasi (Sama seperti store)
        const summary = await tx.dailySummary.findUnique({
          where: {
            meter_id_summary_date: { meter_id: targetMeterId, summary_date: dateForDb },
          },
        });

        if (summary) {
          await _checkUsageAgainstTargetAndNotify(userId, summary, meter, tx);
        }

        return session;
      });
    } catch (error) {
      return handlePrismaError(error, 'Reading Session');
    }
  },

  remove: async (id: number) => {
    try {
      const reading = await prisma.readingSession.findUnique({ where: { session_id: id } });
      if (!reading) throw new Error404('Data tidak ditemukan');

      const newer = await prisma.readingSession.findFirst({
        where: { meter_id: reading.meter_id, reading_date: { gt: reading.reading_date } },
      });
      if (newer) throw new Error400('Hanya data pembacaan terbaru yang boleh dihapus.');

      return await prisma.readingSession.delete({ where: { session_id: id } });
    } catch (error) {
      return handlePrismaError(error, 'Reading Session');
    }
  },

  recalculate: async (payload: PayloadRecalculate) => {
    const { start_date, to_date, meter_id } = payload;
    try {
      const normalizedStart = _normalizeDate(start_date);
      const normalizedEnd = _normalizeDate(to_date);

      return await prisma.$transaction(async (tx: any) => {
        const readingSessions = await tx.readingSession.findMany({
          where: {
            meter_id,
            reading_date: {
              gte: normalizedStart,
              lte: normalizedEnd,
            },
          },
          orderBy: {
            reading_date: 'asc',
          },
        });

        if (readingSessions.length === 0) {
          return {
            message: 'Tidak ada data untuk dikalkulasi ulang pada rentang waktu ini.',
            count: 0,
          };
        }

        for (const session of readingSessions) {
          await formulaEngine.run(meter_id, session.reading_date, tx);
        }

        return {
          message: 'Kalkulasi ulang berhasil.',
          count: readingSessions.length,
        };
      });
    } catch (error) {
      return handlePrismaError(error, 'Recalculate Reading Session');
    }
  },
};
